part of "../index.dart";

abstract class ParamsSerializer<T extends Params> extends Serializer<T> {
  const ParamsSerializer();
}
