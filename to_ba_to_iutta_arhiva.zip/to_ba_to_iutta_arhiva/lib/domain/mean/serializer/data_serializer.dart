part of "../index.dart";

abstract class DataSerializer<T extends Data> extends Serializer<T> {
  const DataSerializer();
}
