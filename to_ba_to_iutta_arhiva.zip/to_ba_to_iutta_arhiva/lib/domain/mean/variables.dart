part of "index.dart";

abstract class Variables {
  const Variables();
}
