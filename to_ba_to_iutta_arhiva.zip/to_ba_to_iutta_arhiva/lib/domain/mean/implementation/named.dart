part of "../index.dart";

abstract class Named {
  String get name;
}
