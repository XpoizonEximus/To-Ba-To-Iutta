part of "index.dart";

abstract class Params {
  const Params();
  ParamsImplementation get implementation;
}
