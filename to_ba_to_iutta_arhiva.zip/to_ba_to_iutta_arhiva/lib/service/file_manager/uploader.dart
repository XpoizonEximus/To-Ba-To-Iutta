import 'package:to_ba_to_iutta/service/file_manager/file_options.dart';

class Uploader {
  final FileOptions fileOptions;

  Uploader(this.fileOptions);

  Future<bool> upload() async {
    throw UnimplementedError();
  }
}
