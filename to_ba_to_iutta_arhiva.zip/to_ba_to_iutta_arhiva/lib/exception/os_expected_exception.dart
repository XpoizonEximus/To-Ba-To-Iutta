class OSExpectedException {
  final String message;

  OSExpectedException(this.message);

  @override
  String toString() {
    return message;
  }
}
